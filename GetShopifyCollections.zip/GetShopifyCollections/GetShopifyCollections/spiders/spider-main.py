# -*- coding: utf-8 -*-
import scrapy
from scrapy import Request
from scrapy.conf import settings
from ..items import DataItem
import console
import re
from bs4 import BeautifulSoup
import pymongo


class SpiderClassName(scrapy.Spider):
    name = 'main'

    def __init__(self):
        self.input_file = 'shop-list.txt'

    def read_shop_list(self):
        with open(self.input_file, 'r', encoding='utf-8') as fp:
            lines = fp.readlines()
            lines = [line.strip() for line in lines]
            lines = [line for line in lines if len(line)]

        DB_URI = settings['MONGO_DB_URI']
        DB_NAME = settings['MONGO_DB_NAME']
        client = pymongo.MongoClient(DB_URI)
        db = client[DB_NAME]
        TABLE_NAME = settings['TABLE_NAME']
        collection = db[TABLE_NAME]
        domains_in_db = collection.find({}, {'_id': 0, 'domain': 1})
        domains_in_db = [item['domain'] for item in domains_in_db]
        client.close()

        tgt_domains = list(set(lines) - set(domains_in_db))
        return tgt_domains

    def start_requests(self):
        target_domains = self.read_shop_list()

        for domain in target_domains:
            url = 'https://www.%s/sitemap_collections_1.xml' % (domain)
            request = Request(url,
                              callback=self.process_response,
                              errback=self.process_error,
                              dont_filter=False)
            request.meta['domain'] = domain
            yield request

    def process_response(self, response):
        domain = response.meta['domain']
        item = DataItem()
        item['domain'] = domain
        xml = BeautifulSoup(response.body, 'lxml')
        item_locs = xml.find_all('loc')
        locs = [loc.get_text() for loc in item_locs]
        titles = [loc.split('/')[-1] for loc in locs]
        item['ct'] = titles
        yield item

    def process_error(self, response):
        pass

    def close(close):
        pass
