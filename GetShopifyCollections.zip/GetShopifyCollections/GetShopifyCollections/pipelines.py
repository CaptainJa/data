# -*- coding: utf-8 -*-
# 验证数据，格式转换，保存数据
from scrapy.exceptions import DropItem
from scrapy.item import Item
from scrapy.conf import settings
import pymongo


class PipelineProcessData(object):
    def open_spider(self, spider):
        DB_URI = settings['MONGO_DB_URI']
        DB_NAME = settings['MONGO_DB_NAME']

        self.client = pymongo.MongoClient(DB_URI)
        self.db = self.client[DB_NAME]

    def close_spider(self, spider):
        self.client.close()

    def process_item(self, item, spider):
        TABLE_NAME = settings['TABLE_NAME']
        collection = self.db[TABLE_NAME]

        data = dict(item) if isinstance(item, Item) else item
        collection.insert_one(data)
        return item
