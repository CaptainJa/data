# -*- coding: utf-8 -*-
# 定义数据结构
from scrapy import Item, Field


class DataItem(Item):
    domain = Field()
    ct = Field()
